#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 28 21:57:06 2017

@author: jorge
"""

#Find unique tag names

import xml.etree.ElementTree as ET  # Use cElementTree or lxml if too slow
import pprint
import re
from collections import defaultdict

osm_file = "Sample.osm"  # Replace this with your osm file

def count_tags(filename):
    tag_count={}
    for event, elem in ET.iterparse(filename, events=('start',)):
        if elem.tag in tag_count:
            tag_count[elem.tag]=tag_count[elem.tag]+1
        else:
            tag_count[elem.tag]=1
    
    return tag_count
    
    
#print count_tags(OSM_FILE)
#print "test"



"""
Your task is to explore the data a bit more.
Before you process the data and add it into your database, you should check the
"k" value for each "<tag>" and see if there are any potential problems.

We have provided you with 3 regular expressions to check for certain patterns
in the tags. As we saw in the quiz earlier, we would like to change the data
model and expand the "addr:street" type of keys to a dictionary like this:
{"address": {"street": "Some value"}}
So, we have to see if we have such tags, and if we have any tags with
problematic characters.

Please complete the function 'key_type', such that we have a count of each of
four tag categories in a dictionary:
  "lower", for tags that contain only lowercase letters and are valid,
  "lower_colon", for otherwise valid tags with a colon in their names,
  "problemchars", for tags with problematic characters, and
  "other", for other tags that do not fall into the other three categories.
See the 'process_map' and 'test' functions for examples of the expected format.
"""


lower = re.compile(r'^([a-z]|_)*$')
lower_colon = re.compile(r'^([a-z]|_)*:([a-z]|_)*$')
problemchars = re.compile(r'[=\+/&<>;\'"\?%#$@\,\. \t\r\n]')


def key_type(element, keys):
    if element.tag == "tag":
        for tag in element.iter("tag"):
            try:
                lo=lower.search(element.attrib['k'])
                if lo:
                    keys['lower']+=1
                    return keys
                loc=lower_colon.search(element.attrib['k'])
                if loc:
                    keys['lower_colon']+=1
                    return keys
                prob=problemchars.search(element.attrib['k'])
                if prob:
                    keys['problemchars']+=1
                    return keys
                else:
                    #print element.attrib['k']
                    keys['other']+=1
                    return keys
            except:
                pass
    return keys
         
            

def process_map(filename):
    keys = {"lower": 0, "lower_colon": 0, "problemchars": 0, "other": 0}
    for _, element in ET.iterparse(filename):
        keys = key_type(element, keys)
    
    return keys
    
process_map(OSM_FILE)
    
#----------------------------------------

#Exploring Users
def get_user(tag):
    return tag.attrib['user']


def process_users(filename):
    users = set()
    for _, element in ET.iterparse(filename):
        for tag in element:
            try:
                u=get_user(tag)
                if u !=None:
                    users.add(u)
            except:
                pass
    return users
#process_users(OSM_FILE)


#Improving Street Names

street_type_re = re.compile(r'\b\S+\.?$', re.IGNORECASE)


expected = ["Street", "Avenue", "Boulevard", "Drive", "Court", "Place", "Square", "Lane", "Road", 
            "Trail", "Parkway", "Commons"]

# UPDATE THIS VARIABLE
mapping = { "St": "Street",
            "St.": "Street",
            "Ave": "Avenue",
            "Rd.": "Road",
            "Ave.": "Avenue",
            
            }


def audit_street_type(street_types, street_name):
    m = street_type_re.search(street_name)
    if m:
        street_type = m.group()
        if street_type not in expected:
            street_types[street_type].add(street_name)
    return street_types


def is_street_name(elem):
    return (elem.attrib['k'] == "addr:street")


def audit(osmfile):
    osm_file = open(osmfile, "r")
    street_types = defaultdict(set)
    for event, elem in ET.iterparse(osm_file, events=("start",)):

        if elem.tag == "node" or elem.tag == "way":
            for tag in elem.iter("tag"):
                if is_street_name(tag):
                    audit_street_type(street_types, tag.attrib['v'])
    osm_file.close()
    return street_types.keys()
    
print audit(osm_file)


def update_name(name, mapping):
    m=street_type_re.search(name)
    name=name[:len(name)-len(m.group())]+mapping[m.group()]
    print name

    return name
    
    
def test():
    st_types = audit(OSMFILE)
    assert len(st_types) == 3
    pprint.pprint(dict(st_types))

    for st_type, ways in st_types.iteritems():
        for name in ways:
            better_name = update_name(name, mapping)
"""

def map_boundary(filename):
    for _, element in ET.iterparse(filename):
        if element.tag == "bounds":
            minlat=float(element.attrib['minlat'])
            minlon=float(element.attrib['minlon'])
            maxlat=float(element.attrib['maxlat'])
            maxlon=float(element.attrib['maxlon'])
            #print y['minlat']
            return minlat,minlon,maxlat,maxlon
            
def boundary_check(filename):
    errors={'wrong_coordinates':0}
    minlat,minlon,maxlat,maxlon=25.6692244, -80.4231834, 25.87093, -80.115347
    for _, element in ET.iterparse(filename):
        if element.tag == "node":
            if (element.attrib['lat']<minlat) or (element.attrib['lat']>maxlat):
                errors['wrong_coordinates']+=1
            elif (element.attrib['lon']<minlon) or (element.attrib['lon']>maxlon):
                errors['wrong_coordinates']+=1
    return errors

print boundary_check(OSM_FILE)
    